<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Student Result Management system</title>
  <link href="style.css" rel="stylesheet" type="text/css" />
  <link rel="icon" href="IIEST logo.png">
 </head>

<body><hr>
  <div id="heading">
    <h3>INDIAN INSTITUTE OF ENGINEERING SCIENCE AND TECHNOLOGY, SHIBPUR</h3>
  </div>
  <hr>
  <div id="logo">
  </div>
  <div class="row1">
    <div id="admin" class="box">
      <a href="AdminLogin.php" class="log">Admin Login</a>
    </div>
    <div id="student" class="box">
       <a href="StudentLogin.php" class="log">Student Login</a>
    </div>

  </div>
  <div class="row2">
     <div id="faculty" class="box">
       <a href="professorlogin.php" class="log">Faculty Login</a>
    </div>
  </div>
</body>

</html>
